<?php
$MESS['ANIGHR_OPENIDCONNECT_INSTALL_NAME'] = "Интеграция с OpenID connect provider (SSO). Авторизация";
$MESS['ANIGHR_OPENIDCONNECT_INSTALL_TITLE'] = "Установка модуля openidconnect";
$MESS['ANIGHR_OPENIDCONNECT_INSTALL_DESCRIPTION'] = "Модуль авторизации через OpenID connect provider";

$MESS["ANIGHR_PARTNER_NAME"] = "anighr";
$MESS["ANIGHR_PARTNER_URI"] = "https://eha.ru/";

?>