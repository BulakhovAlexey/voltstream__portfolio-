<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentDescription = array(
	"NAME" => GetMessage("ANIGHR_OIDC_NAME"),
	"DESCRIPTION" => GetMessage("ANIGHR_OIDC_DESCRIPTION"),
	"ICON" => "/images/icon.gif",
	"PATH" => array(
		"ID" => GetMessage("ANIGHR_OIDC_ID"),
		"CHILD" => array(
			"ID" => "Anighr components",
			"CHILD" => array(
			"ID" => "OpenID_Connect",
			"NAME" => "OpenID Connect SSO"
			)
		)
),
"COMPLEX" => "Y"
);
?>
