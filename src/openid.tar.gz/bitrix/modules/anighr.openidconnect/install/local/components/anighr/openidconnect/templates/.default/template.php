<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

if ($arResult["FatalError"]) {
    echo '<div class="oidc-error" style="color: red; padding: 10px; border: 1px solid red; margin: 10px 0; background: #ffe6e6;">';
    echo '<strong>Ошибка OpenID Connect:</strong> ' . $arResult["FatalError"];
    echo '</div>';
    return;
}

if ($arResult["Success"]) {
    echo '<div class="oidc-success" style="color: green; padding: 10px; border: 1px solid green; margin: 10px 0; background: #e6ffe6;">';
    echo '<strong>✅ Успешная авторизация через ' . $arResult["ProviderName"] . '!</strong><br>';
    echo 'Пользователь: ' . $arResult["UserLogin"] . '<br>';
    if ($arResult["UserEmail"]) {
        echo 'Email: ' . $arResult["UserEmail"] . '<br>';
    }
    echo '</div>';
} elseif ($arResult["ShowAuthButton"]) {
    echo '<div class="oidc-auth-section" style="text-align: center; padding: 20px; border: 1px solid #ddd; margin: 20px 0; background: #f9f9f9;">';
    echo '<h3>Авторизация через ' . $arResult["ProviderName"] . '</h3>';
    echo '<p>Нажмите кнопку ниже для входа через ' . $arResult["ProviderName"] . '</p>';
    echo '<a href="' . $arResult["AuthUrl"] . '" class="oidc-auth-button" style="display: inline-block; padding: 12px 24px; background: #007cba; color: white; text-decoration: none; border-radius: 4px; font-weight: bold;">';
    echo 'Войти через ' . $arResult["ProviderName"];
    echo '</a>';
    echo '</div>';
}
?>
