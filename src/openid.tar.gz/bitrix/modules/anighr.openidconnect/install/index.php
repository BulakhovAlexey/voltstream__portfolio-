<?
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\IO;
use Bitrix\Main\ModuleManager;
use \Bitrix\Main\Loader;

Loc::loadMessages(__FILE__);

if (class_exists("anighr_openidconnect"))
	return;

Class anighr_openidconnect extends CModule
{
	var $MODULE_ID = "anighr.openidconnect";
	var $MODULE_VERSION;
	var $MODULE_VERSION_DATE;
	var $MODULE_NAME;
	var $MODULE_DESCRIPTION;
	var $MODULE_CSS;
	var $MODULE_GROUP_RIGHTS = "Y";

	var $errors = false;

	function __construct()
	{
		$arModuleVersion = array();

		include(__DIR__.'/version.php');

		$this->MODULE_VERSION = $arModuleVersion["VERSION"];
		$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];

		$this->MODULE_NAME = Loc::getMessage("ANIGHR_OPENIDCONNECT_INSTALL_NAME");
		$this->MODULE_DESCRIPTION = Loc::getMessage("ANIGHR_OPENIDCONNECT_INSTALL_DESCRIPTION");
		$this->PARTNER_NAME = Loc::getMessage("ANIGHR_PARTNER_NAME");
		$this->PARTNER_URI = Loc::getMessage("ANIGHR_PARTNER_URI");
	}

	function InstallDB($install_wizard = true)
	{
        global $APPLICATION;
        $this->errors = false;
        \Bitrix\Main\ModuleManager::registerModule("anighr.openidconnect");
        if($this->errors !== false)
		{
			$APPLICATION->ThrowException(implode("<br>", $this->errors));
		}
		return true;
	}

	function UnInstallDB($arParams = Array())
	{
		global $APPLICATION;
		$this->errors = false;
        \Bitrix\Main\ModuleManager::unRegisterModule("anighr.openidconnect");
        if($this->errors !== false)
		{
			$APPLICATION->ThrowException(implode("<br>", $this->errors));
		}
		return true;
	}

	function InstallFiles()
	{
        CopyDirFiles(
            $_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/anighr.openidconnect/install/local/components",
            $_SERVER["DOCUMENT_ROOT"]."/bitrix/components", true, true
        );

		return true;
	}
	function InstallPublic()
	{
	}
	function UnInstallFiles()
	{

        $directory = new IO\Directory($_SERVER["DOCUMENT_ROOT"]."/bitrix/components/anighr");
        try {
            if ($directory->isExists()) {
                $directory->delete();
            }
            return true;
        } catch (IO\IoException $e) {
            AddMessage2Log("Ошибка удаления: ".$e->getMessage(), "anighr.openidconnect");
            return false;
        }
	}

	function DoInstall()
	{
         if (!ModuleManager::isModuleInstalled("anighr.openidconnect"))
        {
        $this->InstallFiles();
        $this->InstallDB();
        }
    }

	function DoUninstall()
	{
        $this->UnInstallFiles();
        $this->UnInstallDB();
    }
}
?>