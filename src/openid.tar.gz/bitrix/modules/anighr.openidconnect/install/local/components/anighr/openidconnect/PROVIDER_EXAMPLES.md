# Примеры конфигурации OpenID Connect провайдеров

## Keycloak

```php
$APPLICATION->IncludeComponent(
    "anighr:openidconnect",
    "",
    Array(
        "PROVIDER_NAME" => "Keycloak",
        "AUTH_URL" => "http://your-keycloak:8080/realms/your-realm/protocol/openid-connect/auth",
        "TOKEN_URL" => "http://your-keycloak:8080/realms/your-realm/protocol/openid-connect/token",
        "USERINFO_URL" => "http://your-keycloak:8080/realms/your-realm/protocol/openid-connect/userinfo",
        "SCOPES" => "openid profile email",
        "CLIENT_ID" => "your-client-id",
        "CLIENT_SECRET" => "your-client-secret",
        "USERNAME_FIELD" => "preferred_username",
        "EMAIL_FIELD" => "email",
        "FIRST_NAME_FIELD" => "given_name",
        "LAST_NAME_FIELD" => "family_name",
        "FULL_NAME_FIELD" => "name",
        "SEARCH_BY_EMAIL" => "Y",
        "ENABLE_REDIRECT" => "Y",
        "REDIRECT_URI" => "/?from=keycloak",
        "DEBUG" => "N"
    )
);
```

## Google

```php
$APPLICATION->IncludeComponent(
    "anighr:openidconnect",
    "",
    Array(
        "PROVIDER_NAME" => "Google",
        "AUTH_URL" => "https://accounts.google.com/o/oauth2/v2/auth",
        "TOKEN_URL" => "https://oauth2.googleapis.com/token",
        "USERINFO_URL" => "https://www.googleapis.com/oauth2/v2/userinfo",
        "SCOPES" => "openid profile email",
        "CLIENT_ID" => "your-google-client-id",
        "CLIENT_SECRET" => "your-google-client-secret",
        "USERNAME_FIELD" => "email",
        "EMAIL_FIELD" => "email",
        "FIRST_NAME_FIELD" => "given_name",
        "LAST_NAME_FIELD" => "family_name",
        "FULL_NAME_FIELD" => "name",
        "SEARCH_BY_EMAIL" => "Y",
        "ENABLE_REDIRECT" => "Y",
        "REDIRECT_URI" => "/?from=google",
        "DEBUG" => "N"
    )
);
```

## Microsoft Azure AD

```php
$APPLICATION->IncludeComponent(
    "anighr:openidconnect",
    "",
    Array(
        "PROVIDER_NAME" => "Microsoft",
        "AUTH_URL" => "https://login.microsoftonline.com/your-tenant-id/oauth2/v2.0/authorize",
        "TOKEN_URL" => "https://login.microsoftonline.com/your-tenant-id/oauth2/v2.0/token",
        "USERINFO_URL" => "https://graph.microsoft.com/oidc/userinfo",
        "SCOPES" => "openid profile email",
        "CLIENT_ID" => "your-microsoft-client-id",
        "CLIENT_SECRET" => "your-microsoft-client-secret",
        "USERNAME_FIELD" => "preferred_username",
        "EMAIL_FIELD" => "email",
        "FIRST_NAME_FIELD" => "given_name",
        "LAST_NAME_FIELD" => "family_name",
        "FULL_NAME_FIELD" => "name",
        "SEARCH_BY_EMAIL" => "Y",
        "ENABLE_REDIRECT" => "Y",
        "REDIRECT_URI" => "/?from=microsoft",
        "DEBUG" => "N"
    )
);
```

## Auth0

```php
$APPLICATION->IncludeComponent(
    "anighr:openidconnect",
    "",
    Array(
        "PROVIDER_NAME" => "Auth0",
        "AUTH_URL" => "https://your-domain.auth0.com/authorize",
        "TOKEN_URL" => "https://your-domain.auth0.com/oauth/token",
        "USERINFO_URL" => "https://your-domain.auth0.com/userinfo",
        "SCOPES" => "openid profile email",
        "CLIENT_ID" => "your-auth0-client-id",
        "CLIENT_SECRET" => "your-auth0-client-secret",
        "USERNAME_FIELD" => "preferred_username",
        "EMAIL_FIELD" => "email",
        "FIRST_NAME_FIELD" => "given_name",
        "LAST_NAME_FIELD" => "family_name",
        "FULL_NAME_FIELD" => "name",
        "SEARCH_BY_EMAIL" => "Y",
        "ENABLE_REDIRECT" => "Y",
        "REDIRECT_URI" => "/?from=auth0",
        "DEBUG" => "N"
    )
);
```

## Okta

```php
$APPLICATION->IncludeComponent(
    "anighr:openidconnect",
    "",
    Array(
        "PROVIDER_NAME" => "Okta",
        "AUTH_URL" => "https://your-domain.okta.com/oauth2/default/v1/authorize",
        "TOKEN_URL" => "https://your-domain.okta.com/oauth2/default/v1/token",
        "USERINFO_URL" => "https://your-domain.okta.com/oauth2/default/v1/userinfo",
        "SCOPES" => "openid profile email",
        "CLIENT_ID" => "your-okta-client-id",
        "CLIENT_SECRET" => "your-okta-client-secret",
        "USERNAME_FIELD" => "preferred_username",
        "EMAIL_FIELD" => "email",
        "FIRST_NAME_FIELD" => "given_name",
        "LAST_NAME_FIELD" => "family_name",
        "FULL_NAME_FIELD" => "name",
        "SEARCH_BY_EMAIL" => "Y",
        "ENABLE_REDIRECT" => "Y",
        "REDIRECT_URI" => "/?from=okta",
        "DEBUG" => "N"
    )
);
```

## Настройка полей для разных провайдеров

### Поля пользователя в ответе от провайдера:

| Провайдер | Username | Email | First Name | Last Name | Full Name |
|-----------|----------|-------|------------|-----------|-----------|
| Keycloak | `preferred_username` | `email` | `given_name` | `family_name` | `name` |
| Google | `email` | `email` | `given_name` | `family_name` | `name` |
| Microsoft | `preferred_username` | `email` | `given_name` | `family_name` | `name` |
| Auth0 | `preferred_username` | `email` | `given_name` | `family_name` | `name` |
| Okta | `preferred_username` | `email` | `given_name` | `family_name` | `name` |

### Дополнительные поля (опционально):

- `sub` - уникальный идентификатор пользователя
- `id` - альтернативный идентификатор
- `display_name` - отображаемое имя
- `nickname` - никнейм
- `picture` - URL аватара

## Отладка

Для включения режима отладки добавьте параметр `"DEBUG" => "Y"` или используйте GET параметр `?debug=qweytqwreqwyqwet66w6w7qw6w66` в URL.

В режиме отладки вы увидите:
- Все URL запросов
- Ответы от провайдера
- Извлеченные данные пользователя
- Процесс поиска/создания пользователя в Bitrix
