<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arComponentParameters = array(
    "GROUPS" => array(
        "PROVIDER_SETTINGS" => array(
            "NAME" => GetMessage("ANIGHR_OIDC_GROUP_PROVIDER_SETTINGS"),
            "SORT" => 100,
        ),
        "USER_SETTINGS" => array(
            "NAME" => GetMessage("ANIGHR_OIDC_GROUP_USER_SETTINGS"),
            "SORT" => 200,
        ),
        "BEHAVIOR_SETTINGS" => array(
            "NAME" => GetMessage("ANIGHR_OIDC_GROUP_BEHAVIOR_SETTINGS"),
            "SORT" => 300,
        ),
    ),
    "PARAMETERS" => array(
        // Настройки провайдера
        "PROVIDER_NAME" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_PROVIDER_NAME"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        "AUTH_URL" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_AUTH_URL"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        "TOKEN_URL" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_TOKEN_URL"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        "USERINFO_URL" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_USERINFO_URL"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        "SCOPES" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_SCOPES"),
            "TYPE" => "STRING",
            "DEFAULT" => "openid profile email",
            "REFRESH" => "N",
        ),
        "CLIENT_ID" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_CLIENT_ID"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        "CLIENT_SECRET" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_CLIENT_SECRET"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        // Redirect override for component callback
        "REDIRECT_COMPONENT_URI" => array(
            "PARENT" => "PROVIDER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_REDIRECT_COMPONENT_URI"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        
        // Настройки полей пользователя
        "USERNAME_FIELD" => array(
            "PARENT" => "USER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_USERNAME_FIELD"),
            "TYPE" => "STRING",
            "DEFAULT" => "preferred_username",
            "REFRESH" => "N",
        ),
        "EMAIL_FIELD" => array(
            "PARENT" => "USER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_EMAIL_FIELD"),
            "TYPE" => "STRING",
            "DEFAULT" => "email",
            "REFRESH" => "N",
        ),
        "FIRST_NAME_FIELD" => array(
            "PARENT" => "USER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_FIRST_NAME_FIELD"),
            "TYPE" => "STRING",
            "DEFAULT" => "given_name",
            "REFRESH" => "N",
        ),
        "LAST_NAME_FIELD" => array(
            "PARENT" => "USER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_LAST_NAME_FIELD"),
            "TYPE" => "STRING",
            "DEFAULT" => "family_name",
            "REFRESH" => "N",
        ),
        "FULL_NAME_FIELD" => array(
            "PARENT" => "USER_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_FULL_NAME_FIELD"),
            "TYPE" => "STRING",
            "DEFAULT" => "name",
            "REFRESH" => "N",
        ),
        
        // Настройки поведения
        "REDIRECT_URI" => array(
            "PARENT" => "BEHAVIOR_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_REDIRECT_URI"),
            "TYPE" => "STRING",
            "DEFAULT" => "",
            "REFRESH" => "N",
        ),
        "ENABLE_REDIRECT" => array(
            "PARENT" => "BEHAVIOR_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_ENABLE_REDIRECT"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N",
            "REFRESH" => "N",
        ),
        "SEARCH_BY_EMAIL" => array(
            "PARENT" => "BEHAVIOR_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_SEARCH_BY_EMAIL"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "Y",
            "REFRESH" => "N",
        ),
        "CREATE_USER_IF_NOT_FOUND" => array(
            "PARENT" => "BEHAVIOR_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_CREATE_USER_IF_NOT_FOUND"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "Y",
            "REFRESH" => "N",
        ),
        "DEBUG" => array(
            "PARENT" => "BEHAVIOR_SETTINGS",
            "NAME" => GetMessage("ANIGHR_OIDC_NAME_DEBUG"),
            "TYPE" => "CHECKBOX",
            "DEFAULT" => "N",
            "REFRESH" => "N",
        ),
    ),
);
?>
