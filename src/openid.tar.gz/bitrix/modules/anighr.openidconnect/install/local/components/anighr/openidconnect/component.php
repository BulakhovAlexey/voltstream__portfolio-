<?php
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

global $USER;

// Параметры компонента
$providerName = $arParams["PROVIDER_NAME"];
$authUrl = $arParams["AUTH_URL"];
$tokenUrl = $arParams["TOKEN_URL"];
$userInfoUrl = $arParams["USERINFO_URL"];
$scopes = $arParams["SCOPES"] ?: 'openid profile email';
$clientId = $arParams["CLIENT_ID"];
$clientSecret = $arParams["CLIENT_SECRET"];
$redirectUri = $arParams["REDIRECT_URI"];
$redirectComponentUri = $arParams["REDIRECT_COMPONENT_URI"];
$searchByEmail = ($arParams["SEARCH_BY_EMAIL"] == 'Y');
$createUserIfNotFound = ($arParams["CREATE_USER_IF_NOT_FOUND"] == 'Y');

// Поля для извлечения данных пользователя
$usernameField = $arParams["USERNAME_FIELD"] ?: 'preferred_username';
$emailField = $arParams["EMAIL_FIELD"] ?: 'email';
$firstNameField = $arParams["FIRST_NAME_FIELD"] ?: 'given_name';
$lastNameField = $arParams["LAST_NAME_FIELD"] ?: 'family_name';
$fullNameField = $arParams["FULL_NAME_FIELD"] ?: 'name';

// Проверяем GET параметр для принудительной отладки
//$forceDebug = (isset($_GET['debug']) && $_GET['debug'] === 'qweytqwreqwyqwet66w6w7qw6w66');
$forceDebug = (isset($_GET['debug']) && false);
$debug = ($arParams["DEBUG"] == 'Y') || $forceDebug;
$enableRedirect = ($arParams["ENABLE_REDIRECT"] == 'Y');

$arResult["redirect_uri"] = $redirectUri;
$arResult["FatalError"] = '';
$arResult["Success"] = false;

if ($debug) {
    if ($forceDebug) {
        echo "Включен режим отладки OpenID Connect через GET параметр! <br><br>";
    } else {
        echo "Включен режим отладки OpenID Connect! <br><br>";
    }
}

if ($debug) {echo "Provider: $providerName<br>";}
if ($debug) {echo "Auth URL: $authUrl<br>";}
if ($debug) {echo "Token URL: $tokenUrl<br>";}
if ($debug) {echo "UserInfo URL: $userInfoUrl<br>";}
if ($debug) {echo "Scopes: $scopes<br>";}
if ($debug) {echo "Client ID: $clientId<br>";}
if ($debug) {echo "Enable Redirect: " . ($enableRedirect ? "Да" : "Нет") . "<br>";}
if ($debug) {echo "Search By Email: " . ($searchByEmail ? "Да" : "Нет") . "<br>";}
if ($debug) {echo "Create User If Not Found: " . ($createUserIfNotFound ? "Да" : "Нет") . "<br>";}
if ($debug) {echo "Redirect URI: $redirectUri<br>";}

// Проверка обязательных параметров
if (empty($authUrl) || empty($tokenUrl) || empty($userInfoUrl) || empty($clientId)) {
    $arResult["FatalError"] = GetMessage("ANIGHR_OIDC_ERROR_MISSING_PARAMS");
    $this->IncludeComponentTemplate();
    return;
}

// Проверяем, есть ли уже авторизованный пользователь
if ($USER->IsAuthorized()) {
    if ($debug) {echo "Пользователь уже авторизован: " . $USER->GetLogin() . "<br>";}
    if ($debug) {echo "User ID: " . $USER->GetID() . "<br>";}
    if ($debug) {echo "User Email: " . $USER->GetEmail() . "<br>";}
    if ($debug) {echo "User Groups: " . implode(", ", $USER->GetUserGroupArray()) . "<br>";}
    $arResult["Success"] = true;
    $arResult["ProviderName"] = $providerName;
    $arResult["UserLogin"] = $USER->GetLogin();
    $arResult["UserEmail"] = $USER->GetEmail();
    
    // Проверяем редирект для уже авторизованного пользователя
    if ($debug) {echo "Проверка редиректа для авторизованного пользователя: enableRedirect=" . ($enableRedirect ? "true" : "false") . ", redirectUri='$redirectUri'<br>";}
    if ($enableRedirect && !empty($redirectUri)) {
        if ($debug) {echo "Выполняем редирект для авторизованного пользователя на: $redirectUri<br>";}
        LocalRedirect($redirectUri);
    } else {
        if ($debug) {echo "Редирект отключен или не настроен для авторизованного пользователя<br>";}
    }
    
    $this->IncludeComponentTemplate();
    return;
}

// Обработка callback от OpenID Connect провайдера
if (isset($_GET['code']) && isset($_GET['state'])) {
    if ($debug) {echo "Получен callback от $providerName<br>";}
    
    $authCode = $_GET['code'];
    $state = $_GET['state'];
    
    // Проверяем state для защиты от CSRF
    if (!isset($_SESSION['oidc_state']) || $state !== $_SESSION['oidc_state']) {
        $arResult["FatalError"] = GetMessage("ANIGHR_OIDC_ERROR_INVALID_STATE");
        $this->IncludeComponentTemplate();
        return;
    }
    
    // Обмениваем код на токен
    if ($debug) {echo "Запрос токена: $tokenUrl<br>";}
    
    // Определяем redirect_uri для обмена кода на токен
    if (!empty($redirectComponentUri)) {
        $currentUrl = $redirectComponentUri;
    } else {
        // Формируем redirect_uri без порта для HTTPS
        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
        $host = $_SERVER['HTTP_HOST'];
        
        // Убираем порт для HTTPS (стандартный порт 443)
        if ($protocol === 'https' && strpos($host, ':443') !== false) {
            $host = str_replace(':443', '', $host);
        }
        
        // Используем только базовый URL без параметров для redirect_uri
        $currentUrl = $protocol . "://" . $host . $_SERVER['SCRIPT_NAME'];
    }
    
    $tokenData = array(
        'grant_type' => 'authorization_code',
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'code' => $authCode,
        'redirect_uri' => $currentUrl
    );
    
    // Используем file_get_contents для HTTP запроса
    $postData = http_build_query($tokenData);
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postData,
            'timeout' => 30
        ]
    ]);
    
    $tokenResponse = @file_get_contents($tokenUrl, false, $context);
    
    // Получаем HTTP код из заголовков
    $httpCode = 200; // По умолчанию считаем успешным
    if (isset($http_response_header)) {
        foreach ($http_response_header as $header) {
            if (strpos($header, 'HTTP/') === 0) {
                $httpCode = (int)substr($header, 9, 3);
                break;
            }
        }
    }
    
    // Если запрос не удался
    if ($tokenResponse === false) {
        $httpCode = 0;
        $tokenResponse = '';
        if ($debug) {echo "Ошибка file_get_contents: " . error_get_last()['message'] . "<br>";}
    }
    
    if ($debug) {echo "HTTP Code: $httpCode<br>";}
    if ($debug) {echo "Token Response: " . substr($tokenResponse, 0, 200) . "...<br>";}
    if ($debug) {echo "Post Data: " . $postData . "<br>";}
    if ($debug) {echo "Response Headers: " . print_r($http_response_header, true) . "<br>";}
    
    if ($httpCode == 200) {
        $tokenData = json_decode($tokenResponse, true);
        
        if (isset($tokenData['access_token'])) {
            $accessToken = $tokenData['access_token'];
            
            // Получаем информацию о пользователе
            if ($debug) {echo "Запрос информации о пользователе: $userInfoUrl<br>";}
            
            // Используем file_get_contents для HTTP запроса
            $context = stream_context_create([
                'http' => [
                    'method' => 'GET',
                    'header' => 'Authorization: Bearer ' . $accessToken,
                    'timeout' => 30
                ]
            ]);
            
            $userInfoResponse = @file_get_contents($userInfoUrl, false, $context);
            
            // Получаем HTTP код из заголовков
            $httpCode = 200; // По умолчанию считаем успешным
            if (isset($http_response_header)) {
                foreach ($http_response_header as $header) {
                    if (strpos($header, 'HTTP/') === 0) {
                        $httpCode = (int)substr($header, 9, 3);
                        break;
                    }
                }
            }
            
            // Если запрос не удался
            if ($userInfoResponse === false) {
                $httpCode = 0;
                $userInfoResponse = '';
                if ($debug) {echo "Ошибка file_get_contents userinfo: " . error_get_last()['message'] . "<br>";}
            }
            
            if ($debug) {echo "User Info HTTP Code: $httpCode<br>";}
            if ($debug) {echo "User Info Response: " . substr($userInfoResponse, 0, 200) . "...<br>";}
            
            if ($httpCode == 200) {
                $userInfo = json_decode($userInfoResponse, true);
                
                if ($debug) {echo "User Info: " . print_r($userInfo, true) . "<br>";}
                
                // Извлекаем данные пользователя с помощью универсальной функции
                $userData = extractUserData($userInfo, $usernameField, $emailField, $firstNameField, $lastNameField, $fullNameField);
                
                $login = $userData['username'];
                $email = $userData['email'];
                $firstName = $userData['first_name'];
                $lastName = $userData['last_name'];
                
                if ($debug) {echo "Extracted Login: $login, Email: $email<br>";}
                if ($debug) {echo "Extracted FirstName: $firstName, LastName: $lastName<br>";}
                
                // Ищем пользователя в Bitrix по логину или email
                $userObj = new CUser;
                $arUser = false;
                
                // Сначала ищем по точному логину
                if (!empty($login)) {
                    if ($debug) {echo "Ищем пользователя по точному логину: $login<br>";}
                    // Используем поиск по логину с последующей ручной проверкой точного совпадения
                    $rsUser = CUser::GetList(($by="id"), ($order="desc"), array("LOGIN" => $login));
                    $arUser = false;
                    while ($userData = $rsUser->Fetch()) {
                        if ($userData['LOGIN'] === $login) {
                            $arUser = $userData;
                            break;
                        }
                    }
                    if ($arUser) {
                        if ($debug) {echo "Пользователь найден по логину: " . $arUser['LOGIN'] . "<br>";}
                    } else {
                        if ($debug) {echo "Пользователь не найден по логину: $login<br>";}
                    }
                }
                
                // Если не найден по логину и включен поиск по email, ищем по точному email
                if (!$arUser && $searchByEmail && !empty($email)) {
                    if ($debug) {echo "Ищем пользователя по точному email: $email<br>";}
                    // Используем поиск по email с последующей ручной проверкой точного совпадения
                    $rsUser = CUser::GetList(($by="id"), ($order="desc"), array("EMAIL" => $email));
                    $arUser = false;
                    while ($userData = $rsUser->Fetch()) {
                        if ($userData['EMAIL'] === $email) {
                            $arUser = $userData;
                            break;
                        }
                    }
                    if ($arUser) {
                        if ($debug) {echo "Пользователь найден по email: " . $arUser['EMAIL'] . "<br>";}
                    } else {
                        if ($debug) {echo "Пользователь не найден по email: $email<br>";}
                    }
                } elseif (!$arUser && !$searchByEmail) {
                    if ($debug) {echo "Поиск по email отключен<br>";}
                } elseif (!$arUser && $searchByEmail && empty($email)) {
                    if ($debug) {echo "Поиск по email включен, но email пустой<br>";}
                }
                
                if ($debug) {echo "Результат поиска пользователя: " . ($arUser ? "найден" : "не найден") . "<br>";}
                
                if ($arUser) {
                    // Пользователь найден, авторизуем
                    if ($debug) {echo "Пользователь найден в Bitrix: " . $arUser['LOGIN'] . "<br>";}
                    
                    $USER->Authorize($arUser['ID']);
                    $arResult["Success"] = true;
                    $arResult["ProviderName"] = $providerName;
                    $arResult["UserLogin"] = $arUser['LOGIN'];
                    $arResult["UserEmail"] = $arUser['EMAIL'];
                    $arResult["UserFirstName"] = $arUser['NAME'];
                    $arResult["UserLastName"] = $arUser['LAST_NAME'];
                    
                    if ($debug) {echo "✅ Пользователь успешно авторизован в Bitrix: " . $arUser['LOGIN'] . "<br>";}
                    if ($debug) {echo "User ID: " . $arUser['ID'] . "<br>";}
                    if ($debug) {echo "User Email: " . $arUser['EMAIL'] . "<br>";}
                    
                    // Перенаправляем на указанную страницу (если включено)
                    if ($debug) {echo "Проверка редиректа: enableRedirect=" . ($enableRedirect ? "true" : "false") . ", redirectUri='$redirectUri'<br>";}
                    if ($enableRedirect && !empty($redirectUri)) {
                        if ($debug) {echo "Выполняем редирект на: $redirectUri<br>";}
                        LocalRedirect($redirectUri);
                    } else {
                        if ($debug) {echo "Редирект отключен или не настроен<br>";}
                    }
                } else {
                    // Пользователь не найден
                    if ($debug) {echo "Пользователь не найден<br>";}
                    
                    if ($createUserIfNotFound) {
                        // Создаем нового пользователя
                        if ($debug) {echo "Создание пользователя включено, создаем нового<br>";}
                        
                        $randomPassword = md5(uniqid());
                        $arFields = array(
                            "LOGIN" => $login,
                            "EMAIL" => $email,
                            "NAME" => $firstName,
                            "LAST_NAME" => $lastName,
                            "ACTIVE" => "Y",
                            "GROUP_ID" => array(2), // Группа "Все пользователи"
                            "PASSWORD" => $randomPassword,
                            "CONFIRM_PASSWORD" => $randomPassword
                        );
                        
                        if ($debug) {echo "Поля для создания пользователя: " . print_r($arFields, true) . "<br>";}
                        
                        $newUserId = $userObj->Add($arFields);
                        
                        if ($newUserId) {
                            if ($debug) {echo "Пользователь создан с ID: $newUserId<br>";}
                            
                            $USER->Authorize($newUserId);
                            $arResult["Success"] = true;
                            $arResult["ProviderName"] = $providerName;
                            $arResult["UserLogin"] = $login;
                            $arResult["UserEmail"] = $email;
                            $arResult["UserFirstName"] = $firstName;
                            $arResult["UserLastName"] = $lastName;
                            
                            if ($debug) {echo "✅ Новый пользователь создан и авторизован в Bitrix<br>";}
                            if ($debug) {echo "New User ID: $newUserId<br>";}
                            if ($debug) {echo "New User Login: $login<br>";}
                            if ($debug) {echo "New User Email: $email<br>";}
                            
                            // Перенаправляем на указанную страницу (если включено)
                            if ($debug) {echo "Проверка редиректа: enableRedirect=" . ($enableRedirect ? "true" : "false") . ", redirectUri='$redirectUri'<br>";}
                            if ($enableRedirect && !empty($redirectUri)) {
                                if ($debug) {echo "Выполняем редирект на: $redirectUri<br>";}
                                LocalRedirect($redirectUri);
                            } else {
                                if ($debug) {echo "Редирект отключен или не настроен<br>";}
                            }
                        } else {
                            if ($debug) {echo "Ошибка создания пользователя: " . $userObj->LAST_ERROR . "<br>";}
                            $arResult["FatalError"] = GetMessage("ANIGHR_OIDC_ERROR_USER_CREATE") . ": " . $userObj->LAST_ERROR;
                        }
                    } else {
                        // Создание пользователя отключено
                        if ($debug) {echo "Создание пользователя отключено<br>";}
                        $arResult["FatalError"] = "Пользователь не найден и создание пользователей отключено";
                    }
                }
            } else {
                $arResult["FatalError"] = GetMessage("ANIGHR_OIDC_ERROR_USER_INFO") . " (HTTP: $httpCode)";
            }
        } else {
            $arResult["FatalError"] = GetMessage("ANIGHR_OIDC_ERROR_TOKEN") . ": " . ($tokenData['error_description'] ?? 'Unknown error');
        }
    } else {
        $arResult["FatalError"] = GetMessage("ANIGHR_OIDC_ERROR_TOKEN_REQUEST") . " (HTTP: $httpCode)";
    }
} else {
    // Показываем кнопку для авторизации через OpenID Connect провайдер
    if ($debug) {echo "Показываем кнопку авторизации через $providerName<br>";}
    
    // Генерируем state для защиты от CSRF
    $state = bin2hex(random_bytes(16));
    $_SESSION['oidc_state'] = $state;
    
    // Определяем redirect_uri для авторизации
    if (!empty($redirectComponentUri)) {
        $currentUrl = $redirectComponentUri;
    } else {
        // Формируем redirect_uri без порта для HTTPS
        $protocol = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
        $host = $_SERVER['HTTP_HOST'];
        
        // Убираем порт для HTTPS (стандартный порт 443)
        if ($protocol === 'https' && strpos($host, ':443') !== false) {
            $host = str_replace(':443', '', $host);
        }
        
        // Используем только базовый URL без параметров для redirect_uri
        $currentUrl = $protocol . "://" . $host . $_SERVER['SCRIPT_NAME'];
    }
    
    $authParams = array(
        'client_id' => $clientId,
        'response_type' => 'code',
        'scope' => $scopes,
        'redirect_uri' => $currentUrl,
        'state' => $state
    );
    
    $authUrl .= '?' . http_build_query($authParams);
    
    if ($debug) {echo "Auth URL: $authUrl<br>";}
    
    // Передаем URL в шаблон для отображения кнопки
    $arResult["AuthUrl"] = $authUrl;
    $arResult["ShowAuthButton"] = true;
    $arResult["ProviderName"] = $providerName;
}

// Финальная проверка состояния авторизации
if ($debug) {
    echo "<br>=== ФИНАЛЬНОЕ СОСТОЯНИЕ ===<br>";
    echo "Success: " . ($arResult["Success"] ? "Да" : "Нет") . "<br>";
    echo "FatalError: " . ($arResult["FatalError"] ?: "Нет") . "<br>";
    echo "User Authorized: " . ($USER->IsAuthorized() ? "Да" : "Нет") . "<br>";
    if ($USER->IsAuthorized()) {
        echo "Current User: " . $USER->GetLogin() . " (ID: " . $USER->GetID() . ")<br>";
    }
    echo "========================<br>";
}

// Универсальная функция извлечения данных пользователя
function extractUserData($userInfo, $usernameField, $emailField, $firstNameField, $lastNameField, $fullNameField) {
    return [
        'id' => $userInfo['sub'] ?? $userInfo['id'] ?? '',
        'username' => $userInfo[$usernameField] ?? $userInfo['sub'] ?? $userInfo['id'] ?? '',
        'email' => $userInfo[$emailField] ?? '',
        'first_name' => $userInfo[$firstNameField] ?? '',
        'last_name' => $userInfo[$lastNameField] ?? '',
        'full_name' => $userInfo[$fullNameField] ?? ''
    ];
}

$this->IncludeComponentTemplate();
?>
