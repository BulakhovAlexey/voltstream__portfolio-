<?php
$arModuleVersion = [
	"VERSION" => "1.0.9",
	"VERSION_DATE" => "2025-11-17 07:47:16"
];
?>