<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

// Parameter groups
$MESS["ANIGHR_OIDC_GROUP_PROVIDER_SETTINGS"] = "Provider Settings";
$MESS["ANIGHR_OIDC_GROUP_USER_SETTINGS"] = "User Field Settings";
$MESS["ANIGHR_OIDC_GROUP_BEHAVIOR_SETTINGS"] = "Behavior Settings";

// Provider settings
$MESS["ANIGHR_OIDC_NAME_PROVIDER_NAME"] = "Provider Name";
$MESS["ANIGHR_OIDC_NAME_AUTH_URL"] = "Authorization URL";
$MESS["ANIGHR_OIDC_NAME_TOKEN_URL"] = "Token URL";
$MESS["ANIGHR_OIDC_NAME_USERINFO_URL"] = "User Info URL";
$MESS["ANIGHR_OIDC_NAME_SCOPES"] = "Requested Scopes";
$MESS["ANIGHR_OIDC_NAME_CLIENT_ID"] = "Client ID";
$MESS["ANIGHR_OIDC_NAME_CLIENT_SECRET"] = "Client Secret";
$MESS["ANIGHR_OIDC_NAME_REDIRECT_COMPONENT_URI"] = "redirect_uri for IDP (page where the component is installed)"; 

// User field settings
$MESS["ANIGHR_OIDC_NAME_USERNAME_FIELD"] = "Username Field";
$MESS["ANIGHR_OIDC_NAME_EMAIL_FIELD"] = "Email Field";
$MESS["ANIGHR_OIDC_NAME_FIRST_NAME_FIELD"] = "First Name Field";
$MESS["ANIGHR_OIDC_NAME_LAST_NAME_FIELD"] = "Last Name Field";
$MESS["ANIGHR_OIDC_NAME_FULL_NAME_FIELD"] = "Full Name Field";

// Behavior settings
$MESS["ANIGHR_OIDC_NAME_REDIRECT_URI"] = "Redirect URI after login";
$MESS["ANIGHR_OIDC_NAME_ENABLE_REDIRECT"] = "Enable redirect after login";
$MESS["ANIGHR_OIDC_NAME_SEARCH_BY_EMAIL"] = "Search user by email if not found by login";
$MESS["ANIGHR_OIDC_NAME_CREATE_USER_IF_NOT_FOUND"] = "If user not found - create";
$MESS["ANIGHR_OIDC_NAME_DEBUG"] = "Debug mode";
?>
