<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

// Группы параметров
$MESS["ANIGHR_OIDC_GROUP_PROVIDER_SETTINGS"] = "Настройки провайдера";
$MESS["ANIGHR_OIDC_GROUP_USER_SETTINGS"] = "Настройки полей пользователя";
$MESS["ANIGHR_OIDC_GROUP_BEHAVIOR_SETTINGS"] = "Настройки поведения";

// Настройки провайдера
$MESS["ANIGHR_OIDC_NAME_PROVIDER_NAME"] = "Название провайдера";
$MESS["ANIGHR_OIDC_NAME_AUTH_URL"] = "URL для авторизации";
$MESS["ANIGHR_OIDC_NAME_TOKEN_URL"] = "URL для получения токена";
$MESS["ANIGHR_OIDC_NAME_USERINFO_URL"] = "URL для получения информации о пользователе";
$MESS["ANIGHR_OIDC_NAME_SCOPES"] = "Запрашиваемые области (scopes)";
$MESS["ANIGHR_OIDC_NAME_CLIENT_ID"] = "Client ID";
$MESS["ANIGHR_OIDC_NAME_CLIENT_SECRET"] = "Client Secret";
$MESS["ANIGHR_OIDC_NAME_REDIRECT_COMPONENT_URI"] = "redirect_uri для отправки в IDP (страница где установлен компонент)";

// Настройки полей пользователя
$MESS["ANIGHR_OIDC_NAME_USERNAME_FIELD"] = "Поле для логина";
$MESS["ANIGHR_OIDC_NAME_EMAIL_FIELD"] = "Поле для email";
$MESS["ANIGHR_OIDC_NAME_FIRST_NAME_FIELD"] = "Поле для имени";
$MESS["ANIGHR_OIDC_NAME_LAST_NAME_FIELD"] = "Поле для фамилии";
$MESS["ANIGHR_OIDC_NAME_FULL_NAME_FIELD"] = "Поле для полного имени";

// Настройки поведения
$MESS["ANIGHR_OIDC_NAME_REDIRECT_URI"] = "URI для перенаправления после входа";
$MESS["ANIGHR_OIDC_NAME_ENABLE_REDIRECT"] = "Включить перенаправление после входа";
$MESS["ANIGHR_OIDC_NAME_SEARCH_BY_EMAIL"] = "Поиск пользователя по email если не найден по логину";
$MESS["ANIGHR_OIDC_NAME_CREATE_USER_IF_NOT_FOUND"] = "Если пользователь не найден - создать";
$MESS["ANIGHR_OIDC_NAME_DEBUG"] = "Режим отладки";
?>
