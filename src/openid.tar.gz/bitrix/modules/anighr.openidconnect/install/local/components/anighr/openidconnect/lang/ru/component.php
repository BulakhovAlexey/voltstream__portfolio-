<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS["ANIGHR_OIDC_NAME"] = "OpenID Connect SSO";
$MESS["ANIGHR_OIDC_DESCRIPTION"] = "Универсальный компонент для авторизации пользователей через OpenID Connect провайдеры (Keycloak, Google, Microsoft, Auth0 и др.)";
$MESS["ANIGHR_OIDC_ID"] = "Кастомные";

$MESS["ANIGHR_OIDC_ERROR_MISSING_PARAMS"] = "Отсутствуют обязательные параметры настройки";
$MESS["ANIGHR_OIDC_ERROR_INVALID_STATE"] = "Неверный state параметр";
$MESS["ANIGHR_OIDC_ERROR_TOKEN"] = "Ошибка получения токена";
$MESS["ANIGHR_OIDC_ERROR_TOKEN_REQUEST"] = "Ошибка запроса токена";
$MESS["ANIGHR_OIDC_ERROR_USER_INFO"] = "Ошибка получения информации о пользователе";
$MESS["ANIGHR_OIDC_ERROR_USER_CREATE"] = "Ошибка создания пользователя";
$MESS["ANIGHR_OIDC_NAME_REDIRECT_COMPONENT_URI"] = "redirect_uri для отправки в IPD";
?>
