<?
$MESS ['ANIGHR_OIDC_NAME'] = "OpenID Connect SSO";
$MESS ['ANIGHR_OIDC_DESCRIPTION'] = "Универсальный компонент для авторизации пользователей через OpenID Connect провайдеры (Keycloak, Google, Microsoft, Auth0 и др.)";
$MESS ['ANIGHR_OIDC_ID'] = "Кастомные";

?>
