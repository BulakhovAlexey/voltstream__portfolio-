<?
$MESS ['ANIGHR_OIDC_NAME'] = "OpenID Connect SSO";
$MESS ['ANIGHR_OIDC_DESCRIPTION'] = "Universal component for user authentication via OpenID Connect providers (Keycloak, Google, Microsoft, Auth0, etc.)";
$MESS ['ANIGHR_OIDC_ID'] = "Custom";

?>
