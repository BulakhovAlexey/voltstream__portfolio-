<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$MESS["ANIGHR_OIDC_NAME"] = "OpenID Connect SSO";
$MESS["ANIGHR_OIDC_DESCRIPTION"] = "Universal component for user authentication via OpenID Connect providers (Keycloak, Google, Microsoft, Auth0, etc.)";
$MESS["ANIGHR_OIDC_ID"] = "Custom";

$MESS["ANIGHR_OIDC_ERROR_MISSING_PARAMS"] = "Missing required configuration parameters";
$MESS["ANIGHR_OIDC_ERROR_INVALID_STATE"] = "Invalid state parameter";
$MESS["ANIGHR_OIDC_ERROR_TOKEN"] = "Token retrieval error";
$MESS["ANIGHR_OIDC_ERROR_TOKEN_REQUEST"] = "Token request error";
$MESS["ANIGHR_OIDC_ERROR_USER_INFO"] = "User information retrieval error";
$MESS["ANIGHR_OIDC_ERROR_USER_CREATE"] = "User creation error";
$MESS["ANIGHR_OIDC_NAME_REDIRECT_COMPONENT_URI"] = "redirect_uri for IDP"; 
?>
